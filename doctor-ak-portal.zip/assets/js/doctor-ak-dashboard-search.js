/**
 * Doctor AK Portal — dashboard topbar search box (Admin: Doctors, Patients,
 * Receptionists, Admins, Appointments, Services, Doctor Sessions, Clinic
 * Locations, Doctor Requests, Encounters; Doctor: their own Patients,
 * Appointments, Services, Clinics; Patient: Doctors + Appointments).
 * Searches on Enter (not as-you-type) with a click-to-jump results dropdown;
 * each result links to its row via an existing `#dak-{type}-{id}` anchor
 * (`:target` highlight already built for notification deep-links).
 */
( function () {
	'use strict';

	var GROUP_LABELS = {
		doctors: 'Doctors',
		patients: 'Patients',
		receptionist: 'Receptionist',
		admin: 'Admins',
		appointments: 'Appointments',
		services: 'Services',
		doctor_sessions: 'Doctor Sessions',
		clinic_locations: 'Clinic Locations',
		doctor_requests: 'Doctor Requests',
		encounters: 'Encounters',
		clinics: 'Clinics',
	};

	var MIN_QUERY_LENGTH = 2;

	document.addEventListener( 'DOMContentLoaded', function () {
		var input = document.getElementById( 'dak-dashboard-topbar-search' );
		var results = document.getElementById( 'dak-dashboard-topbar-search-results' );

		if ( ! input || ! results ) {
			return;
		}

		var action = input.getAttribute( 'data-live-search' );
		var nonceSource = input.getAttribute( 'data-live-search-nonce' );
		var groups = ( input.getAttribute( 'data-live-search-groups' ) || '' ).split( ',' ).filter( Boolean );
		var requestId = 0;

		// Clearing the box hides whatever results are still showing, but
		// typing otherwise does nothing until Enter is pressed — see
		// keydown below.
		input.addEventListener( 'input', function () {
			if ( '' === input.value.trim() ) {
				hideResults();
			}
		} );

		input.addEventListener( 'focus', function () {
			if ( results.children.length > 0 && input.value.trim().length >= MIN_QUERY_LENGTH ) {
				showResults();
			}
		} );

		document.addEventListener( 'click', function ( event ) {
			if ( event.target !== input && ! results.contains( event.target ) ) {
				hideResults();
			}
		} );

		input.addEventListener( 'keydown', function ( event ) {
			if ( 'Enter' === event.key ) {
				event.preventDefault();

				var query = input.value.trim();

				if ( query.length < MIN_QUERY_LENGTH ) {
					hideResults();
					return;
				}

				runSearch( query );
			} else if ( 'Escape' === event.key ) {
				hideResults();
				input.blur();
			}
		} );

		function runSearch( query ) {
			var nonceData = nonceSource ? window[ nonceSource ] : null;

			if ( ! nonceData || ! action ) {
				return;
			}

			var thisRequest = ++requestId;
			var formData = new FormData();
			formData.append( 'action', action );
			formData.append( 'nonce', nonceData.nonce );
			formData.append( 'query', query );

			fetch( nonceData.ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' } )
				.then( function ( response ) { return response.json(); } )
				.then( function ( result ) {
					if ( thisRequest !== requestId ) {
						return; // A newer keystroke's request already landed — discard this stale one.
					}

					if ( result.success && result.data ) {
						renderResults( result.data, query );
					}
				} )
				.catch( function () {
					if ( thisRequest === requestId ) {
						hideResults();
					}
				} );
		}

		function renderResults( data, query ) {
			results.innerHTML = '';

			var totalCount = 0;

			groups.forEach( function ( groupKey ) {
				var items = data[ groupKey ];

				if ( ! items || 0 === items.length ) {
					return;
				}

				totalCount += items.length;

				var groupEl = document.createElement( 'div' );
				groupEl.className = 'dak-search-results-group';

				var heading = document.createElement( 'div' );
				heading.className = 'dak-search-results-group-label';
				heading.textContent = GROUP_LABELS[ groupKey ] || groupKey;
				groupEl.appendChild( heading );

				items.forEach( function ( item ) {
					var link = document.createElement( 'a' );
					link.className = 'dak-search-result-item';
					link.href = item.url || '#';

					var label = document.createElement( 'span' );
					label.className = 'dak-search-result-label';
					label.textContent = item.label;
					link.appendChild( label );

					if ( item.sublabel ) {
						var sublabel = document.createElement( 'span' );
						sublabel.className = 'dak-search-result-sublabel';
						sublabel.textContent = item.sublabel;
						link.appendChild( sublabel );
					}

					groupEl.appendChild( link );
				} );

				results.appendChild( groupEl );
			} );

			if ( 0 === totalCount ) {
				var empty = document.createElement( 'div' );
				empty.className = 'dak-search-results-empty';
				empty.textContent = 'No results found for "' + query + '"';
				results.appendChild( empty );
			}

			showResults();
		}

		function showResults() {
			results.classList.remove( 'dak-hidden' );
		}

		function hideResults() {
			results.classList.add( 'dak-hidden' );
		}
	} );
} )();
